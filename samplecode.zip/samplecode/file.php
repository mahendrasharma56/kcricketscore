<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Requests\AdminRequest;
use App\Helpers\RegionHelper;
use App\Helpers\UserHelper;
use App\Helpers\ViewHelper;
use App\Helpers\OptionHelper;
use App\Helpers\ClusterHelper;
use App\Helpers\AppHelper;
use App\Helpers\PackageHelper;
use App\Helpers\PlanHelper;
use App\Helpers\SubscriptionHelper;

class AdminController extends BaseController
{
    /**
     * Create a new instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();

        $this->middleware('auth:api');
        $this->middleware('is-expected-admin');
    }

    /**
     * Returns the current user's view data.
     *
     * @param  \App\Http\Requests\AdminRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function getData(AdminRequest $request)
    {
        $this->includeFractalResource(ViewHelper::getAdminFractalPaths());

        $data = ViewHelper::getUserData($request->user);

        return $this->respondWithItems($data);
    }

    /**
     * Marks user notification as read.
     *
     * @param  \App\Http\Requests\AdminRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function markUserNotificationAsRead(AdminRequest $request)
    {
        $this->validateRequest($request, [
            'guid' => 'required|string',
        ]);

        UserHelper::markNotificationAsRead($request->guid);

        return $this->respondWithOk();
    }

    /**
     * Sets bulk options.
     *
     * @param  \App\Http\Requests\AdminRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function createOrUpdateOptions(AdminRequest $request)
    {
        $this->validateRequest($request, [
            'options'               => 'required|array',
            'options.*.name'        => 'required|alpha_dash|max:64',
            'options.*.value'       => 'present|string',
            'options.*.category'    => 'nullable|string'
        ]);

        $options = [];
        foreach ($request->options as $option) {
            $options[] = OptionHelper::createOrUpdate(
                $option['name'],
                $option['value'],
                $option['category'] ?? null
            );
        }

        RegionHelper::syncOptionsWithAll();

        return $this->respondWithItems($options);
    }

    /**
     * Creates a new user.
     *
     * @param  \App\Http\Requests\AdminRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function createUser(AdminRequest $request)
    {
        $this->validateRequest($request, [
            'display_name'  => 'required|unique:users,display_name',
            'email'         => 'required|email|unique:users,email',
            'password'      => 'required|string|min:8',
            'role'          => 'required|in:admin,partner'
        ]);

        switch ($request->role) {
            case 'admin':
                $user = UserHelper::createAdmin($request->all());
                break;
            case 'partner':
                $user = UserHelper::createPartner($request->all());
                break;
            default:
                $this->exception("Invalid user role.");
                break;
        }

        return $this->respondWithItem($user);
    }

    /**
     * Deletes an existing user.
     *
     * @param  \App\Http\Requests\AdminRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function deleteUser(AdminRequest $request)
    {
        $this->validateRequest($request, [
            'user_slug' => 'required|exists:users,slug'
        ]);

        UserHelper::delete($request->all());

        return $this->respondWithOk();
    }

    /**
     * Returns all activity by user.
     *
     * @param  \App\Http\Requests\AdminRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function getUserActions(AdminRequest $request)
    {
        $this->validateRequest($request, [
            'user_slug' => 'required|exists:users,slug',
            'page' => 'nullable|integer|min:1',
            'limit' => 'nullable|integer|min:1'
        ]);

        $actions = UserHelper::getActionLogs($request->all());

        return $this->respondWithItems($actions);
    }

    /**
     * Returns all regions.
     *
     * @param  \App\Http\Requests\AdminRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function getRegions(AdminRequest $request)
    {
        $regions = RegionHelper::all();

        return $this->respondWithItem($regions);
    }

    /**
     * Creates a new region.
     *
     * @param  \App\Http\Requests\AdminRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function createRegion(AdminRequest $request)
    {
        $this->validateRequest($request, [
            'region_slug'   => 'required|unique:regions,slug',
            'display_name'  => 'required',
            'erm_endpoint'  => 'required|unique:regions,erm_endpoint',
            'description'   => 'nullable|string',
        ]);

        $region = RegionHelper::createOrUpdate($request->all());

        return $this->respondWithItem($region);
    }

    /**
     * Updates an existing region.
     *
     * @param  \App\Http\Requests\AdminRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function updateRegion(AdminRequest $request)
    {
        $this->validateRequest($request, [
            'region_slug'   => 'required|exists:regions,slug',
            'display_name'  => 'required',
            'erm_endpoint'  => 'required',
            'description'   => 'nullable'
        ]);

        $region = RegionHelper::createOrUpdate($request->all());

        return $this->respondWithItem($region);
    }

    /**
     * Deletes an existing region.
     *
     * @param  \App\Http\Requests\AdminRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function deleteRegion(AdminRequest $request)
    {
        $this->validateRequest($request, [
            'region_slug'   => 'required|exists:regions,slug',
        ]);

        RegionHelper::delete($request->all());
        
        return $this->respondWithOk();
    }

    /**
     * Creates a new cluster.
     *
     * @param  \App\Http\Requests\AdminRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function createCluster(AdminRequest $request)
    {
        $this->validateRequest($request, [
            'region_slug'   => 'required|exists:regions,slug',
            'cluster_slug'  => 'required|unique:clusters,slug|min:5|max:18',
            'instance_type' => 'required'
        ]);

        $cluster = ClusterHelper::create($request->all());

        return $this->respondWithItem($cluster);
    }

    /**
     * Deletes the specified cluster.
     *
     * @param  \App\Http\Requests\AdminRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function deleteCluster(AdminRequest $request)
    {
        $this->validateRequest($request, [
            'cluster_slug' => 'required|exists:clusters,slug',
        ]);

        ClusterHelper::delete($request->all());

        return $this->respondWithOk();
    }

    /**
     * Syncs and updates clusters system status.
     *
     * @param  \App\Http\Requests\AdminRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function updateClustersSystemStatus(AdminRequest $request)
    {
        $this->validateRequest($request, [
            'region_slug' => 'required|exists:regions,slug',
        ]);

        RegionHelper::updateClustersSystemStatus($request->all());

        return $this->respondWithOk();
    }

    /**
     * Syncs ewsm apps in all region's clusters.
     *
     * @param  \App\Http\Requests\AdminRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function syncEwsmCode(AdminRequest $request)
    {
        $this->validateRequest($request, [
            'region_slug' => 'required|exists:regions,slug',
        ]);

        RegionHelper::syncEwsmCode($request->all());
        
        return $this->respondWithOk();
    }

    /**
     * Syncs ewsm apps in all region's clusters.
     *
     * @param  \App\Http\Requests\AdminRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function execEwsmShell(AdminRequest $request)
    {
        $this->validateRequest($request, [
            'script_slug'       => 'required|in:custom_script',
            'cluster_slugs'     => 'required|array',
            'cluster_slugs.*'   => 'string|exists:clusters,slug',
            'shell_context'     => 'required|string',
            'is_sync'           => 'nullable|boolean',
        ]);

        $result = RegionHelper::execEwsmShell($request->all());
        
        return $this->respondWithJson($result);
    }

    /**
     * Update supervisor's queue listener processes number.
     *
     * @param  \App\Http\Requests\AdminRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function updateQueueProcNum(AdminRequest $request)
    {
        $this->validateRequest($request, [
            'cluster_slug'  => 'required|exists:clusters,slug',
            'procs_num'     => 'required|integer|min:1|max:5'
        ]);

        ClusterHelper::setQueueProcsNum($request->all());

        return $this->respondWithOk();
    }

    /**
     * Download the certificate of the specified cluster.
     *
     * @param  \App\Http\Requests\AdminRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function downloadClusterCertificate(AdminRequest $request)
    {
        $this->validateRequest($request, [
            'cluster_slug' => 'required|exists:clusters,slug',
        ]);

        $info = ClusterHelper::getCertificate($request->all());

        return $this->respondWithFileDownload($info['filename'], $info['content']);
    }

    /**
     * Reboots the specified cluster.
     *
     * @param  \App\Http\Requests\AdminRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function rebootCluster(AdminRequest $request)
    {
        $this->validateRequest($request, [
            'cluster_slug' => 'required|exists:clusters,slug',
        ]);

        ClusterHelper::reboot($request->all());

        return $this->respondWithOk();
    }

    /**
     * Sets the specified cluster as primary instance.
     *
     * @param  \App\Http\Requests\AdminRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function setClusterPrimaryInstance(AdminRequest $request)
    {
        $this->validateRequest($request, [
            'cluster_slug'  => 'required|exists:clusters,slug',
            'instance_id'   => 'required|string',
            'switch_only'   => 'nullable|boolean',
        ]);

        ClusterHelper::setPrimaryInstance($request->all());

        return $this->respondWithOk();
    }

    /**
     * Syncs the specified cluster's instance with the primary's data.
     *
     * @param  \App\Http\Requests\AdminRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function syncClusterInstanceData(AdminRequest $request)
    {
        $this->validateRequest($request, [
            'cluster_slug'  => 'required|exists:clusters,slug',
            'instance_id'   => 'required|string',
        ]);

        ClusterHelper::syncInstanceData($request->all());

        return $this->respondWithOk();
    }

    /**
     * Clones the specified cluster's instance.
     *
     * @param  \App\Http\Requests\AdminRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function cloneClusterInstance(AdminRequest $request)
    {
        $this->validateRequest($request, [
            'cluster_slug'  => 'required|exists:clusters,slug',
            'instance_id'   => 'required|string'
        ]);

        ClusterHelper::cloneInstance($request->all());

        return $this->respondWithOk();
    }

    /**
     * Reboots the specified cluster's instance.
     *
     * @param  \App\Http\Requests\AdminRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function rebootClusterInstance(AdminRequest $request)
    {
        $this->validateRequest($request, [
            'cluster_slug'  => 'required|exists:clusters,slug',
            'instance_id'   => 'required|string'
        ]);

        ClusterHelper::rebootInstance($request->all());

        return $this->respondWithOk();
    }

    /**
     * Deletes the specified cluster's instance.
     *
     * @param  \App\Http\Requests\AdminRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function deleteClusterInstance(AdminRequest $request)
    {
        $this->validateRequest($request, [
            'cluster_slug'  => 'required|exists:clusters,slug',
            'instance_id'   => 'required|string'
        ]);

        ClusterHelper::deleteInstance($request->all());

        return $this->respondWithOk();
    }

    /**
     * Returns the ERM activity logs.
     *
     * @param  \App\Http\Requests\AdminRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function getRegionActivityLogs(AdminRequest $request)
    {
        $this->validateRequest($request, [
            'region_slug'   => 'required|exists:regions,slug',
            'type'          => 'required|string|in:any,proc,job,command',
            'display'       => 'required|string|in:any,success_only,failed_only',
            'limit'         => 'nullable|integer|min:1|max:1000',
            'name'          => 'nullable|string',
        ]);

        $logs = RegionHelper::activityLogs($request->all());

        return $this->respondWithJson($logs);
    }

    /**
     * Returns the AWS activity logs.
     *
     * @param  \App\Http\Requests\AdminRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function getRegionAwsLogs(AdminRequest $request)
    {
        $this->validateRequest($request, [
            'region_slug'   => 'required|exists:regions,slug',
            'limit'         => 'nullable|integer',
            'days_ago'      => 'nullable|integer',
            'service'       => 'nullable|string',
            'function'      => 'nullable|string',
            'display'       => 'nullable|in:any,success_only,failed_only',
        ]);

        $logs = RegionHelper::awsLogs($request->all());

        return $this->respondWithJson($logs);
    }

    /**
     * Returns all packages.
     *
     * @param  \App\Http\Requests\AdminRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function getPackages(AdminRequest $request)
    {
        $packages = PackageHelper::getAll();

        return $this->respondWithItem($packages);
    }

    /**
     * Creates a new package.
     *
     * @param  \App\Http\Requests\AdminRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function createPackage(AdminRequest $request)
    {
        $this->validateRequest($request, [
            'folder_name'   => 'required',
            'display_name'  => 'required',
            'version'       => 'required',
            'type'          => 'required|in:plugin,theme,core',
            'must_install'  => 'required|boolean',
            'description'   => 'nullable',
            'src'           => 'nullable',
            'official_uri'  => 'nullable',
            'author'        => 'nullable',
            'author_uri'    => 'nullable',
            'must_activate' => 'boolean|nullable'
        ]);

        $package = PackageHelper::create($request->all());
        
        return $this->respondWithItem($package);
    }

    /**
     * Updates an existing package.
     *
     * @param  \App\Http\Requests\AdminRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function updatePackage(AdminRequest $request)
    {
        $this->validateRequest($request, [
            'package_slug'  => 'required|exists:packages,slug',
            'folder_name'   => 'required',
            'display_name'  => 'required',
            'version'       => 'required',
            'type'          => 'required|in:plugin,theme,core',
            'must_install'  => 'required|boolean',
            'description'   => 'nullable',
            'src'           => 'nullable',
            'official_uri'  => 'nullable',
            'author'        => 'nullable',
            'author_uri'    => 'nullable',
            'must_activate' => 'boolean|nullable'
        ]);

        $package = PackageHelper::update($request->all());
        
        return $this->respondWithItem($package);
    }

    /**
     * Returns the presigned URL of the specified package.
     *
     * @param  \App\Http\Requests\AdminRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function getPackageDownloadUrl(AdminRequest $request)
    {
        $this->validateRequest($request, [
            'package_slug' => 'required|exists:packages,slug',
        ]);

        $url = PackageHelper::getDownloadUrl($request->all());

        return $this->respondWithJson([
            'download_url' => $url,
            'package_slug' => $request->package_slug
        ]);
    }

    /**
     * Deletes an existing package.
     *
     * @param  \App\Http\Requests\AdminRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function deletePackage(AdminRequest $request)
    {
        $this->validateRequest($request, [
            'package_slug' => 'required|exists:packages,slug',
        ]);

        PackageHelper::delete($request->all());

        return $this->respondWithOk();
    }

    /**
     * Fetches the package metadata.
     *
     * @param  \App\Http\Requests\AdminRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function fetchPackageMetadata(AdminRequest $request)
    {
        $this->validateRequest($request, [
            'file'  => 'max:25000|mimes:zip',
            'src'   => 'nullable',
        ]);

        if ($request->hasFile('file')) {
            $metadata = PackageHelper::fetchMetadataFromUploadedFile($request->file('file'));
        } else {
            $metadata = PackageHelper::fetchMetadata($request->src);
        }

        return $this->respondWithJson($metadata);
    }

    /**
     * Updates WP options for a specific app.
     *
     * @param  \App\Http\Requests\AdminRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function updateAppWpOptions(AdminRequest $request)
    {
        $this->validateRequest($request, [
            'app_slug'          => 'required|exists:apps,slug',
            'options'           => 'present|array',
            'options.*.name'    => 'required|alpha_dash|max:64',
            'options.*.value'   => 'present|string',
            'options.*.type'    => 'nullable|string'
        ]);

        $app = AppHelper::updateWpOptions($request->all());

        return $this->respondWithItem($app);
    }

    /**
     * Updates WP options for a specific app.
     *
     * @param  \App\Http\Requests\AdminRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function updateAppWpDefines(AdminRequest $request)
    {
        $this->validateRequest($request, [
            'app_slug'          => 'required|exists:apps,slug',
            'defines'           => 'present|array',
            'defines.*.name'    => 'required|alpha_dash|max:64',
            'defines.*.value'   => 'present|string',
            'defines.*.type'    => 'nullable|string'
        ]);

        $app = AppHelper::updateWpDefines($request->all());

        return $this->respondWithItem($app);
    }

    /**
     * Updates cron jobs for a specific app.
     *
     * @param  \App\Http\Requests\AdminRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function updateAppCronJobs(AdminRequest $request)
    {
        $this->validateRequest($request, [
            'app_slug'              => 'required|exists:apps,slug',
            'crons'                 => 'required|array',
            'crons.*.interval'      => 'required|string',
            'crons.*.expression'    => 'present|string',
            'crons.*.command'       => 'required|string',
        ]);

        $app = AppHelper::updateCronJobs($request->all());

        return $this->respondWithItem($app);
    }
    
    /**
     * Upgrade or downgrade wordpress version.
     *
     * @param  \App\Http\Requests\AdminRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function updateAppWordpress(AdminRequest $request)
    {
        $this->validateRequest($request, [
            'app_slug'      => 'required|exists:apps,slug',
            'wp_version'    => 'required|string',
        ]);

        AppHelper::updateWordpress($request->all());

        return $this->respondWithOk();
    }

    /**
     * Runs the app links checker.
     *
     * @param  \App\Http\Requests\AdminRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function checkAppLinks(AdminRequest $request)
    {
        $this->validateRequest($request, [
            'app_slug'  => 'required|exists:apps,slug',
            'is_sync'   => 'required|boolean',
        ]);

        $result = AppHelper::checkLinks($request->all());

        return $this->respondWithJson([
            'is_sync' => $request->is_sync,
            'output'  => $result
        ]);
    }

    /**
     * Executes WP CLI command on the specified app.
     *
     * @param  \App\Http\Requests\AdminRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function execAppWpCli(AdminRequest $request)
    {
        $this->validateRequest($request, [
            'app_slug'  => 'required|exists:apps,slug',
            'command'   => 'present|string',
        ]);

        $output = AppHelper::execWpCliFromString($request->all());

        return $this->respondWithJson($output);
    }

    /**
     * Purges WP rocket cache.
     *
     * @param  \App\Http\Requests\AdminRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function purgeAppCache(AdminRequest $request)
    {
        $this->validateRequest($request, [
            'app_slug'      => 'required|exists:apps,slug',
            'permalinks'    => 'present|string',
        ]);

        AppHelper::cleanWpRocketCache($request->all());

        return $this->respondWithOk();
    }

    /**
     * Updates an existing app domains.
     *
     * @param  \App\Http\Requests\AdminRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function updateAppDomains(AdminRequest $request)
    {
        $this->validateRequest($request, [
            'app_slug'          => 'required|exists:apps,slug',
            'domains'           => 'nullable|array',
            'domains.*'         => 'string',
            'default_domain'    => 'nullable|string',
            'delay_propagation' => 'nullable|boolean',
        ]);

        $app = AppHelper::updateDomains($request->all());

        return $this->respondWithItem($app);
    }

    /**
     * Updates an existing app server runtime config.
     *
     * @param  \App\Http\Requests\AdminRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function updateAppRuntimeConfig(AdminRequest $request)
    {
        $this->validateRequest($request, [
            'app_slug'              => 'required|exists:apps,slug',
            'max_execution_time'    => 'required|string|in:default,45,60,180,300',
            'memory_limit'          => 'required|string|in:default,64M,128M,256M,512M',
            'upload_max_filesize'   => 'required|string|in:default,5M,10M,15M,50M,200M,500M',
            'post_max_size'         => 'required|string|in:default,5M,10M,15M,50M,200M,500M',
        ]);

        $app = AppHelper::updateRuntimeConfig($request->all());

        return $this->respondWithItem($app);
    }

    /**
     * Updates an existing app debug mode.
     *
     * @param  \App\Http\Requests\AdminRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function updateAppDebugMode(AdminRequest $request)
    {
        $this->validateRequest($request, [
            'app_slug'  => 'required|exists:apps,slug',
            'mode'      => 'required|in:on,off'
        ]);

        $app = AppHelper::updateDebugMode($request->all());

        return $this->respondWithItem($app);
    }

    /**
     * Creates a dns zone for app.
     *
     * @param  \App\Http\Requests\AdminRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function createAppDnsZone(AdminRequest $request)
    {
        $this->validateRequest($request, [
            'app_slug'      => 'required|exists:apps,slug',
            'name'          => 'required|string',
            'a_records'     => 'nullable|array',
            'a_records.*'   => 'nullable|string',
        ]);

        $dnsZone = AppHelper::createDnsZone($request->all());

        return $this->respondWithItem($dnsZone);
    }

    /**
     * Assigns an existing DNS record to app.
     *
     * @param  \App\Http\Requests\AdminRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function assignAppDnsZone(AdminRequest $request)
    {
        $this->validateRequest($request, [
            'app_slug'      => 'required|exists:apps,slug',
            'dns_zone_slug' => 'required|exists:dns_zones,slug'
        ]);

        $app = AppHelper::assignDnsZone($request->all());

        return $this->respondWithItem($app);
    }

    /**
     * Unassigns the dns zone from app.
     *
     * @param  \App\Http\Requests\AdminRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function unassignAppDnsZone(AdminRequest $request)
    {
        $this->validateRequest($request, [
            'app_slug' => 'required|exists:apps,slug'
        ]);

        $app = AppHelper::unassignDnsZone($request->all());

        return $this->respondWithItem($app);
    }

    /**
     * Deletes an existing app.
     *
     * @param  \App\Http\Requests\AdminRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function deleteApp(AdminRequest $request)
    {
        $this->validateRequest($request, [
            'app_slug' => 'required|exists:apps,slug'
        ]);

        AppHelper::delete($request->all());

        return $this->respondWithOk();
    }

    /**
     * Returns all app actions.
     *
     * @param  \App\Http\Requests\AdminRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function getAppActions(AdminRequest $request)
    {
        $this->validateRequest($request, [
            'app_slug'  => 'required|exists:apps,slug',
            'page'      => 'nullable|integer|min:1',
            'limit'     => 'nullable|integer|min:1'
        ]);

        $actions = AppHelper::getActionLogs($request->all());

        return $this->respondWithItems($actions);
    }

    /**
     * Returns nginx logs of the specified app.
     *
     * @param  \App\Http\Requests\AdminRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function getAppNginxLogs(AdminRequest $request)
    {
        $this->validateRequest($request, [
            'app_slug' => 'required|exists:apps,slug'
        ]);

        $logs = AppHelper::getNginxLogs($request->all());

        return $this->respondWithJson($logs);
    }

    /**
     * Returns app statistical analytics.
     *
     * @param  \App\Http\Requests\AdminRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function getAppStats(AdminRequest $request)
    {
        $this->validateRequest($request, [
            'app_slug' => 'required|exists:apps,slug',
            'days_ago' => 'required|integer|min:1|max:30'
        ]);

        $stats = AppHelper::getStats($request->all());

        return $this->respondWithItem($stats);
    }

    /**
     * Deploys a new CDN distribution to the specified app.
     *
     * @param  \App\Http\Requests\AdminRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function deployCdn(AdminRequest $request)
    {
        $this->validateRequest($request, [
            'app_slug'          => 'required|exists:apps,slug',
            'cdn_domain'        => 'required|unique:app_cdns,domain',
            'validation_method' => 'nullable|in:DNS,EMAIL'
        ]);

        $cdn = AppHelper::deployCdn($request->all());

        return $this->respondWithItem($cdn);
    }

    /**
     * Returns app credentials.
     *
     * @param  \App\Http\Requests\AdminRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function getAppCredentials(AdminRequest $request)
    {
        $this->validateRequest($request, [
            'app_slug' => 'required|exists:apps,slug'
        ]);

        $credentials = AppHelper::getCredentials($request->all());

        return $this->respondWithJson($credentials);
    }

    /**
     * Searches/replaces strings in the database.
     *
     * @param  \App\Http\Requests\AdminRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function searchReplaceAppDb(AdminRequest $request)
    {
        $this->validateRequest($request, [
            'app_slug'  => 'required|exists:apps,slug',
            'old'       => 'required|string',
            'new'       => 'required|string',
            'dry_run'   => 'nullable|boolean'
        ]);

        $rowsAffected = AppHelper::searchReplaceDb($request->all());

        return $this->respondWithJson([
            'rows_affected' => $rowsAffected,
            'dry_run' => $request->dry_run
        ]);
    }

    /**
     * Searches/replaces strings in the database.
     *
     * @param  \App\Http\Requests\AdminRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function bulkSearchReplaceAppDb(AdminRequest $request)
    {
        $this->validateRequest($request, [
            'app_slug'              => 'required|exists:apps,slug',
            'replacements'          => 'required|array',
            'replacements.*.old'    => 'string',
            'replacements.*.new'    => 'string',
        ]);

        AppHelper::bulkSearchReplaceDb($request->all());

        return $this->respondWithJson();
    }

    /**
     * Activates app plugin.
     *
     * @param  \App\Http\Requests\AdminRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function activateAppPlugin(AdminRequest $request)
    {
        $this->validateRequest($request, [
            'app_slug'      => 'required|exists:apps,slug',
            'plugin_slug'   => 'required'
        ]);

        $app = AppHelper::switchPluginMode($request->all(), true);

        return $this->respondWithJson([
            'active_plugins' => $app->active_plugins
        ]);
    }

    /**
     * Deactivates app plugin.
     *
     * @param  \App\Http\Requests\AdminRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function deactivateAppPlugin(AdminRequest $request)
    {
        $this->validateRequest($request, [
            'app_slug'      => 'required|exists:apps,slug',
            'plugin_slug'   => 'required'
        ]);

        $app = AppHelper::switchPluginMode($request->all(), false);

        return $this->respondWithJson([
            'active_plugins' => $app->active_plugins
        ]);
    }

    /**
     * Switches app theme.
     *
     * @param  \App\Http\Requests\AdminRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function switchAppTheme(AdminRequest $request)
    {
        $this->validateRequest($request, [
            'app_slug'      => 'required|exists:apps,slug',
            'theme_slug'    => 'required'
        ]);

        $app = AppHelper::switchTheme($request->all());

        return $this->respondWithJson([
            'active_theme' => $app->active_theme
        ]);
    }

    /**
     * Creates a new or updates an existing plan.
     *
     * @param  \App\Http\Requests\AdminRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function savePlan(AdminRequest $request)
    {
        $this->validateRequest($request, [
            'plan_slug'                     => 'nullable|string|exists:plans,slug',
            'plan_sub_category_slug'        => 'required|string|exists:plan_sub_categories,slug',
            'name'                          => 'required|string',
            'description'                   => 'present|string',
            'price'                         => 'required|numeric',
            'interval'                      => 'required|in:month,year',
            'interval_count'                => 'required|integer|gt:0',
            'charged_immediately'           => 'required|boolean',
            'is_default'                    => 'required|boolean',
            'partner_slug'                  => 'nullable|exists:users,slug',
            'features'                      => 'present|array',
            'features.*.slug'               => 'nullable|string',
            'features.*.name'               => 'required|string',
            'features.*.value'              => 'nullable',
            'features.*.type'               => 'required|string|in:basic,limit',
            'features.*.description'        => 'present|string',
            'features.*.unit'               => 'nullable',
            'features.*.limit'              => 'nullable|integer',
            'features.*.is_hidden'          => 'nullable|boolean',
            'features.*.allow_extra_units'  => 'nullable|boolean',
            'features.*.extra_unit_price'   => 'required|numeric',
        ]);

        $params = $request->all();
        $params['seller_user']  = null;
        $params['assignee']     = $request->partner;
        PlanHelper::save($params);

        return $this->respondWithOk();
    }

    /**
     * Returns all customer plan subscriptions
     *
     * @param  \App\Http\Requests\AdminRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function getPlanSubscriptions(AdminRequest $request)
    {
        $this->validateRequest($request, [
            'plan_slug' => 'string|exists:plans,slug',
        ]);

        $subscriptions = SubscriptionHelper::getByPlan($request->all());

        return $this->respondWithItems($subscriptions);
    }

    /**
     * Cancels a plan subscription.
     *
     * @param  \App\Http\Requests\AdminRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function cancelPlanSubscription(AdminRequest $request)
    {
        $this->validateRequest($request, [
            'guid'              => 'string|exists:plan_subscriptions,guid',
            'delete_usage_data' => 'boolean',
        ]);

        $subscription = SubscriptionHelper::cancel($request->all());
        
        return $this->respondWithItem($subscription);
    }

    /**
     * Uncancels a plan subscription.
     *
     * @param  \App\Http\Requests\AdminRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function uncancelPlanSubscription(AdminRequest $request)
    {
        $this->validateRequest($request, [
            'guid' => 'string|exists:plan_subscriptions,guid',
        ]);

        $subscription = SubscriptionHelper::uncancel($request->all());
        
        return $this->respondWithItem($subscription);
    }

    /**
     * Cancels a plan subscription.
     *
     * @param  \App\Http\Requests\AdminRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function resetPlanSubscriptionUsage(AdminRequest $request)
    {
        $this->validateRequest($request, [
            'guid' => 'string|exists:plan_subscriptions,guid',
        ]);

        $subscription = SubscriptionHelper::clearUsage($request->all());
        
        return $this->respondWithItem($subscription);
    }

    /**
     * Cancels a plan subscription.
     *
     * @param  \App\Http\Requests\AdminRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function deletePlanSubscription(AdminRequest $request)
    {
        $this->validateRequest($request, [
            'guid' => 'string|exists:plan_subscriptions,guid',
        ]);

        $subscription = SubscriptionHelper::delete($request->all());
        
        return $this->respondWithOk();
    }

    /**
     * Creates a new or updates an existing plan subscription.
     *
     * @param  \App\Http\Requests\AdminRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function savePlanSubscription(AdminRequest $request)
    {
        $this->validateRequest($request, [
            'guid'          => 'nullable|string|exists:plan_subscriptions,guid',
            'plan_slug'     => 'required|string|exists:plans,slug',
            'partner_slug'  => 'required|exists:users,slug',
            'name'          => 'required|string',
            'starts_at'     => 'required|date'
        ]);

        $params = $request->all();
        $params['subscriber'] = $request->partner;

        $subscription = !$request->exists('guid')
            ? SubscriptionHelper::create($params)
            : SubscriptionHelper::update($params);

        return $this->respondWithItem($subscription);
    }
}
