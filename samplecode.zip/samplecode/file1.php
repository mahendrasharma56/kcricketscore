<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Requests\EmployeeRequest;
use App\Helpers\ViewHelper;
use App\Helpers\PermissionHelper;
use App\Helpers\ClusterHelper;
use App\Helpers\AppHelper;
use App\Helpers\PackageHelper;
use App\Helpers\DnsZoneHelper;
use App\Helpers\MailboxHelper;
use App\Helpers\MigratorHelper;
use App\Helpers\UserHelper;

class EmployeeController extends BaseController
{
    /**
     * Create a new instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();

        $this->middleware('auth:api');
        $this->middleware('is-expected-employee');
    }
    
    /**
     * Returns the current user's view data.
     *
     * @param  \App\Http\Requests\EmployeeRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function getData(EmployeeRequest $request)
    {
        $data = ViewHelper::getUserData($request->user);

        return $this->respondWithItems($data);
    }

    /**
     * Marks user notification as read.
     *
     * @param  \App\Http\Requests\EmployeeRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function markUserNotificationAsRead(EmployeeRequest $request)
    {
        $this->validateRequest($request, [
            'guid' => 'required|string',
        ]);

        UserHelper::markNotificationAsRead($request->guid);

        return $this->respondWithOk();
    }

    /**
     * Creates a new cluster.
     *
     * @param  \App\Http\Requests\EmployeeRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function createCluster(EmployeeRequest $request)
    {
        $this->validateRequest($request, [
            'region_slug'   => 'required|exists:regions,slug',
            'cluster_slug'  => 'required|unique:clusters,slug|min:5|max:18',
            'instance_type' => 'required'
        ]);

        if (! PermissionHelper::canUserCreateCluster($request->user, $request->region)) {
            return $this->respondWithUnauthorized();
        };

        $requestAll = $this->requestAllWithPartner($request);
        $cluster    = ClusterHelper::create($requestAll);

        PermissionHelper::giveUserPermissionToUpdateCluster($request->user, $cluster);
        PermissionHelper::giveUserPermissionToDeleteCluster($request->user, $cluster);
        PermissionHelper::giveUserPermissionToCreateApps($request->user, $cluster);

        // TODO: turn into events to create permissions

        return $this->respondWithItem($cluster);
    }

    /**
     * Reboots the specified cluster.
     *
     * @param  \App\Http\Requests\EmployeeRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function rebootCluster(EmployeeRequest $request)
    {
        $this->validateRequest($request, [
            'cluster_slug' => 'required|exists:clusters,slug',
        ]);

        if (! PermissionHelper::canUserUpdateCluster($request->user, $request->cluster)) {
            return $this->respondWithUnauthorized();
        };

        $cluster = ClusterHelper::reboot($request->all());

        return $this->respondWithOk();
    }

    /**
     * Deletes the specified cluster.
     *
     * @param  \App\Http\Requests\EmployeeRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function deleteCluster(EmployeeRequest $request)
    {
        $this->validateRequest($request, [
            'cluster_slug' => 'required|exists:clusters,slug',
        ]);

        if (! PermissionHelper::canUserDeleteCluster($request->user, $request->cluster)) {
            return $this->respondWithUnauthorized();
        };

        ClusterHelper::delete($request->all());

        // TODO: events to delete permissions

        return $this->respondWithOk();
    }

    /**
     * Connects to the old site being migrated and tries to initiate
     * a handshake with it (Elemento Migrator plugin) and retrieve
     * the site details.
     *
     * @param  \App\Http\Requests\EmployeeRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function getMigratorExportConfig(EmployeeRequest $request)
    {
        $this->validateRequest($request, [
            'cluster_slug'  => 'required|exists:clusters,slug',
            'app_slug'      => 'required|string',
            'site_url'      => 'required|url',
        ]);

        if (!MigratorHelper::handshake($request->site_url)) {
            return $this->exception("Connection to {$request->site_url} failed.");
        }

        // Get old site's info
        $info = MigratorHelper::getSiteInfo($request->site_url);

        // Create recommended export config from old site's info
        $conf = MigratorHelper::createExportConfig(
            $info,
            $request->cluster,
            $request->app_slug
        );

        return $this->respondWithJson($conf);
    }

    /**
     * Connects to the old site and checks the export process status.
     *
     * @param  \App\Http\Requests\EmployeeRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function getMigratorExportStatus(EmployeeRequest $request)
    {
        $this->validateRequest($request, [
            'site_url'      => 'required|url',
            'process_id'    => 'required|string',
        ]);

        $status = MigratorHelper::getExportTaskStatus(
            $request->site_url,
            $request->process_id
        );

        if (!$status) {
            $this->exception("Failed to read export status.");
        }

        return $this->respondWithJson($status);
    }

    /**
     * Exports website data.
     *
     * @param  \App\Http\Requests\EmployeeRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function scheduleMigratorExportData(EmployeeRequest $request)
    {
        $this->validateRequest($request, [
            'export_config' => 'required|array',
            'site_url'      => 'required|url',
        ]);

        $fileInfo = MigratorHelper::exportSiteData(
            $request->site_url,
            $request->export_config
        );

        return $fileInfo;
    }

    /**
     * Creates a new app.
     *
     * @param  \App\Http\Requests\EmployeeRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function createApp(EmployeeRequest $request)
    {
        $this->validateRequest($request, [
            'cluster_slug'          => 'required|exists:clusters,slug',
            'app_slug'              => 'required|unique:apps,slug',
            'site_title'            => 'required|string',
            'theme_slug'            => 'required',
            'wp_admin_user'         => 'required|string',
            'wp_admin_user_email'   => 'required|email',
            'wp_version'            => 'required|string',
            'plugin_slugs'          => 'nullable|array',
            'migration_config'      => 'nullable|array',
            'migration_data_url'    => 'nullable|url'
        ]);

        if (! PermissionHelper::canUserCreateApp($request->user, $request->cluster)) {
            return $this->respondWithUnauthorized();
        };

        $app = AppHelper::create($request->all());

        PermissionHelper::giveUserPermissionToUpdateApp($request->user, $app);
        PermissionHelper::giveUserPermissionToDeleteApp($request->user, $app);

        return $this->respondWithItem($app);
    }

    /**
     * Updates WP options for a specific app.
     *
     * @param  \App\Http\Requests\EmployeeRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function updateAppWpOptions(EmployeeRequest $request)
    {
        $this->validateRequest($request, [
            'app_slug'          => 'required|exists:apps,slug',
            'options'           => 'present|array',
            'options.*.name'    => 'required|alpha_dash|max:64',
            'options.*.value'   => 'present|string',
            'options.*.type'    => 'nullable|string'
        ]);

        if (! PermissionHelper::canUserUpdateApp($request->user, $request->app)) {
            return $this->respondWithUnauthorized();
        };
        
        $app = AppHelper::updateWpOptions($request->all());

        return $this->respondWithItem($app);
    }

    /**
     * Updates WP options for a specific app.
     *
     * @param  \App\Http\Requests\EmployeeRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function updateAppWpDefines(EmployeeRequest $request)
    {
        $this->validateRequest($request, [
            'app_slug'          => 'required|exists:apps,slug',
            'defines'           => 'present|array',
            'defines.*.name'    => 'required|alpha_dash|max:64',
            'defines.*.value'   => 'present|string',
            'defines.*.type'    => 'nullable|string'
        ]);

        if (! PermissionHelper::canUserUpdateApp($request->user, $request->app)) {
            return $this->respondWithUnauthorized();
        };

        $app = AppHelper::updateWpDefines($request->all());

        return $this->respondWithItem($app);
    }

    /**
     * Updates cron jobs for a specific app.
     *
     * @param  \App\Http\Requests\EmployeeRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function updateAppCronJobs(EmployeeRequest $request)
    {
        $this->validateRequest($request, [
            'app_slug'              => 'required|exists:apps,slug',
            'crons'                 => 'required|array',
            'crons.*.interval'      => 'required|string',
            'crons.*.expression'    => 'present|string',
            'crons.*.command'       => 'required|string',
        ]);

        if (! PermissionHelper::canUserUpdateApp($request->user, $request->app)) {
            return $this->respondWithUnauthorized();
        };
        
        $app = AppHelper::updateCronJobs($request->all());

        return $this->respondWithItem($app);
    }

    /**
     * Upgrade or downgrade wordpress version.
     *
     * @param  \App\Http\Requests\EmployeeRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function updateAppWordpress(EmployeeRequest $request)
    {
        $this->validateRequest($request, [
            'app_slug'      => 'required|exists:apps,slug',
            'wp_version'    => 'required|string',
        ]);

        if (! PermissionHelper::canUserUpdateApp($request->user, $request->app)) {
            return $this->respondWithUnauthorized();
        };
        
        AppHelper::updateWordpress($request->all());

        return $this->respondWithOk();
    }

    /**
     * Runs the app links checker.
     *
     * @param  \App\Http\Requests\EmployeeRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function checkAppLinks(EmployeeRequest $request)
    {
        $this->validateRequest($request, [
            'app_slug'  => 'required|exists:apps,slug',
            'is_sync'   => 'required|boolean',
        ]);

        if (! PermissionHelper::canUserUpdateApp($request->user, $request->app)) {
            return $this->respondWithUnauthorized();
        };
        
        $result = AppHelper::checkLinks($request->all());

        return $this->respondWithJson([
            'is_sync' => $request->is_sync,
            'output'  => $result
        ]);
    }

    /**
     * Executes WP CLI command on the specified app.
     *
     * @param  \App\Http\Requests\EmployeeRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function execAppWpCli(EmployeeRequest $request)
    {
        $this->validateRequest($request, [
            'app_slug'  => 'required|exists:apps,slug',
            'command'   => 'present|string',
        ]);

        if (! PermissionHelper::canUserUpdateApp($request->user, $request->app)) {
            return $this->respondWithUnauthorized();
        };

        $output = AppHelper::execWpCliFromString($request->all());

        return $this->respondWithJson($output);
    }

    /**
     * Purges WP rocket cache.
     *
     * @param  \App\Http\Requests\EmployeeRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function purgeAppCache(EmployeeRequest $request)
    {
        $this->validateRequest($request, [
            'app_slug'      => 'required|exists:apps,slug',
            'permalinks'    => 'present|string',
        ]);

        if (! PermissionHelper::canUserUpdateApp($request->user, $request->app)) {
            return $this->respondWithUnauthorized();
        };

        AppHelper::cleanWpRocketCache($request->all());

        return $this->respondWithOk();
    }
    
    /**
     * Updates an existing app domains.
     *
     * @param  \App\Http\Requests\EmployeeRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function updateAppDomains(EmployeeRequest $request)
    {
        $this->validateRequest($request, [
            'app_slug'          => 'required|exists:apps,slug',
            'domains'           => 'nullable|array',
            'domains.*'         => 'string',
            'default_domain'    => 'nullable|string',
            'delay_propagation' => 'nullable|boolean',
        ]);

        if (! PermissionHelper::canUserUpdateApp($request->user, $request->app)) {
            return $this->respondWithUnauthorized();
        };

        $app = AppHelper::updateDomains($request->all());

        return $this->respondWithItem($app);
    }

    /**
     * Updates an existing app debug mode.
     *
     * @param  \App\Http\Requests\EmployeeRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function updateAppDebugMode(EmployeeRequest $request)
    {
        $this->validateRequest($request, [
            'app_slug'  => 'required|exists:apps,slug',
            'mode'      => 'required|in:on,off'
        ]);

        if (! PermissionHelper::canUserUpdateApp($request->user, $request->app)) {
            return $this->respondWithUnauthorized();
        };

        $app = AppHelper::updateDebugMode($request->all());

        return $this->respondWithItem($app);
    }

    /**
     * Updates an existing app server runtime config.
     *
     * @param  \App\Http\Requests\EmployeeRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function updateAppRuntimeConfig(EmployeeRequest $request)
    {
        $this->validateRequest($request, [
            'app_slug'              => 'required|exists:apps,slug',
            'max_execution_time'    => 'required|string|in:default,45,60,180,300',
            'memory_limit'          => 'required|string|in:default,64M,128M,256M,512M',
            'upload_max_filesize'   => 'required|string|in:default,5M,10M,15M,50M,200M,500M',
            'post_max_size'         => 'required|string|in:default,5M,10M,15M,50M,200M,500M',
        ]);

        if (! PermissionHelper::canUserUpdateApp($request->user, $request->app)) {
            return $this->respondWithUnauthorized();
        };
        
        $app = AppHelper::updateRuntimeConfig($request->all());

        return $this->respondWithItem($app);
    }

    /**
     * Deletes an existing app.
     *
     * @param  \App\Http\Requests\EmployeeRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function deleteApp(EmployeeRequest $request)
    {
        $this->validateRequest($request, [
            'app_slug' => 'required|exists:apps,slug'
        ]);

        if (! PermissionHelper::canUserDeleteApp($request->user, $request->app)) {
            return $this->respondWithUnauthorized();
        };

        AppHelper::delete($request->all());

        return $this->respondWithOk();
    }

    /**
     * Returns app statistical analytics.
     *
     * @param  \App\Http\Requests\EmployeeRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function getAppStats(EmployeeRequest $request)
    {
        $this->validateRequest($request, [
            'app_slug' => 'required|exists:apps,slug',
            'days_ago' => 'required|integer|min:1|max:30'
        ]);

        if (! PermissionHelper::canUserUpdateApp($request->user, $request->app)) {
            return $this->respondWithUnauthorized();
        };

        $stats = AppHelper::getStats($request->all());

        return $this->respondWithItem($stats);
    }

    /**
     * Returns nginx logs of the specified app.
     *
     * @param  \App\Http\Requests\EmployeeRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function getAppNginxLogs(EmployeeRequest $request)
    {
        $this->validateRequest($request, [
            'app_slug' => 'required|exists:apps,slug'
        ]);

        $logs = AppHelper::getNginxLogs($request->all());

        return $this->respondWithJson($logs);
    }
    
    /**
     * Deploys a new CDN distribution to the specified app.
     *
     * @param  \App\Http\Requests\EmployeeRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function deployCdn(EmployeeRequest $request)
    {
        $this->validateRequest($request, [
            'app_slug'          => 'required|exists:apps,slug',
            'cdn_domain'        => 'required|unique:app_cdns,domain',
            'validation_method' => 'nullable|in:DNS,EMAIL'
        ]);

        if (! PermissionHelper::canUserUpdateApp($request->user, $request->app)) {
            return $this->respondWithUnauthorized();
        };

        $cdn = AppHelper::deployCdn($request->all());

        return $this->respondWithItem($cdn);
    }

    /**
     * Creates a dns zone for app.
     *
     * @param  \App\Http\Requests\EmployeeRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function createAppDnsZone(EmployeeRequest $request)
    {
        $this->validateRequest($request, [
            'app_slug'      => 'required|exists:apps,slug',
            'name'          => 'required|string',
            'a_records'     => 'required|array',
            'a_records.*'   => 'required|string',
        ]);

        if (! PermissionHelper::canUserUpdateApp($request->user, $request->app)) {
            return $this->respondWithUnauthorized();
        };
        
        $dnsZone = AppHelper::createDnsZone($request->all());

        return $this->respondWithItem($dnsZone);
    }
    
    /**
     * Checks whether the app slug exists.
     *
     * @param  \App\Http\Requests\EmployeeRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function checkIfAppExists(EmployeeRequest $request)
    {
        $this->validateRequest($request, [
            'app_slug' => 'required'
        ]);

        return $this->respondWithJson([
            'result' => ! is_null($request->app)
        ]);
    }

    /**
     * Returns app credentials.
     *
     * @param  \App\Http\Requests\EmployeeRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function getAppCredentials(EmployeeRequest $request)
    {
        $this->validateRequest($request, [
            'app_slug' => 'required|exists:apps,slug'
        ]);

        if (! PermissionHelper::canUserUpdateApp($request->user, $request->app)) {
            return $this->respondWithUnauthorized();
        };

        $credentials = AppHelper::getCredentials($request->all());

        return $this->respondWithJson($credentials);
    }

    /**
     * Searches/replaces strings in the database.
     *
     * @param  \App\Http\Requests\EmployeeRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function searchReplaceAppDb(EmployeeRequest $request)
    {
        $this->validateRequest($request, [
            'app_slug'  => 'required|exists:apps,slug',
            'old'       => 'required|string',
            'new'       => 'required|string',
            'dry_run'   => 'nullable|boolean'
        ]);

        if (! PermissionHelper::canUserUpdateApp($request->user, $request->app)) {
            return $this->respondWithUnauthorized();
        };

        $rowsAffected = AppHelper::searchReplaceDb($request->all());

        return $this->respondWithJson([
            'rows_affected' => $rowsAffected,
            'dry_run' => $request->dry_run
        ]);
    }


    /**
     * Searches/replaces strings in the database.
     *
     * @param  \App\Http\Requests\EmployeeRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function bulkSearchReplaceAppDb(EmployeeRequest $request)
    {
        $this->validateRequest($request, [
            'app_slug'              => 'required|exists:apps,slug',
            'replacements'          => 'required|array',
            'replacements.*.old'    => 'string',
            'replacements.*.new'    => 'string',
        ]);

        if (! PermissionHelper::canUserUpdateApp($request->user, $request->app)) {
            return $this->respondWithUnauthorized();
        };

        AppHelper::bulkSearchReplaceDb($request->all());

        return $this->respondWithJson();
    }
    
    /**
     * Activates app plugin.
     *
     * @param  \App\Http\Requests\EmployeeRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function activateAppPlugin(EmployeeRequest $request)
    {
        $this->validateRequest($request, [
            'app_slug'      => 'required|exists:apps,slug',
            'plugin_slug'   => 'required'
        ]);

        if (! PermissionHelper::canUserUpdateApp($request->user, $request->app)) {
            return $this->respondWithUnauthorized();
        };

        $app = AppHelper::switchPluginMode($request->all(), true);

        return $this->respondWithJson([
            'active_plugins' => $app->active_plugins
        ]);
    }

    /**
     * Deactivates app plugin.
     *
     * @param  \App\Http\Requests\EmployeeRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function deactivateAppPlugin(EmployeeRequest $request)
    {
        $this->validateRequest($request, [
            'app_slug'      => 'required|exists:apps,slug',
            'plugin_slug'   => 'required'
        ]);

        if (! PermissionHelper::canUserUpdateApp($request->user, $request->app)) {
            return $this->respondWithUnauthorized();
        };

        $app = AppHelper::switchPluginMode($request->all(), false);

        return $this->respondWithJson([
            'active_plugins' => $app->active_plugins
        ]);
    }

    /**
     * Switches app theme.
     *
     * @param  \App\Http\Requests\EmployeeRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function switchAppTheme(EmployeeRequest $request)
    {
        $this->validateRequest($request, [
            'app_slug'      => 'required|exists:apps,slug',
            'theme_slug'    => 'required'
        ]);

        if (! PermissionHelper::canUserUpdateApp($request->user, $request->app)) {
            return $this->respondWithUnauthorized();
        };

        $app = AppHelper::switchTheme($request->all());

        return $this->respondWithJson([
            'active_theme' => $app->active_theme
        ]);
    }

    /**
     * Creates a new package.
     *
     * @param  \App\Http\Requests\EmployeeRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function createPackage(EmployeeRequest $request)
    {
        $this->validateRequest($request, [
            'folder_name'   => 'required',
            'partner_slug'  => 'required|exists:users,slug',
            'app_slug'      => 'nullable|exists:apps,slug',
            'display_name'  => 'required',
            'zip_size'      => 'required|integer',
            'dir_size'      => 'required|integer',
            'local_src'     => 'required',
            'src'           => 'nullable',
            'version'       => 'required',
            'type'          => 'required|in:plugin,theme',
            'description'   => 'required',
            'must_install'  => 'required|boolean',
            'official_uri'  => 'nullable',
            'author'        => 'nullable',
            'author_uri'    => 'nullable',
            'must_activate' => 'boolean|nullable'
        ]);

        if (! PermissionHelper::canUserCreatePackage($request->user, $request->partner, $request->app)) {
            return $this->respondWithUnauthorized();
        };

        $package = PackageHelper::create($request->all());

        if ($package->isPartner()) {
            PermissionHelper::giveUserPermissionToUpdatePartnerPackage($request->user, $package);
            PermissionHelper::giveUserPermissionToDeletePartnerPackage($request->user, $package);
        }
        
        return $this->respondWithItem($package);
    }

    /**
     * Downloads an existing package.
     *
     * @param  \App\Http\Requests\EmployeeRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function downloadPackage(EmployeeRequest $request)
    {
        $this->validateRequest($request, [
            'package_slug' => 'required|exists:packages,slug',
        ]);

        if (! PermissionHelper::canUserUpdatePackage($request->user, $request->package)) {
            return $this->respondWithUnauthorized();
        };
        
        $info = PackageHelper::download($request->all());

        return $this->respondWithFileDownload($info['filename'], $info['content']);
    }

    /**
     * Updates an existing package.
     *
     * @param  \App\Http\Requests\EmployeeRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function updatePackage(EmployeeRequest $request)
    {
        $this->validateRequest($request, [
            'package_slug'  => 'required|exists:packages,slug',
            'partner_slug'  => 'required|exists:users,slug',
            'app_slug'      => 'nullable|exists:apps,slug',
            'folder_name'   => 'required',
            'display_name'  => 'required',
            'version'       => 'required',
            'type'          => 'required|in:plugin,theme',
            'must_install'  => 'required|boolean',
            'src'           => 'nullable',
            'official_uri'  => 'nullable',
            'author'        => 'nullable',
            'author_uri'    => 'nullable',
            'must_activate' => 'boolean|nullable'
        ]);

        if (! PermissionHelper::canUserUpdatePackage($request->user, $request->package)) {
            return $this->respondWithUnauthorized();
        };

        $package = PackageHelper::update($request->all());
        
        return $this->respondWithItem($package);
    }

    /**
     * Deletes an existing package.
     *
     * @param  \App\Http\Requests\EmployeeRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function deletePackage(EmployeeRequest $request)
    {
        $this->validateRequest($request, [
            'package_slug' => 'required|exists:packages,slug',
        ]);

        if (! PermissionHelper::canUserDeletePackage($request->user, $request->package)) {
            return $this->respondWithUnauthorized();
        };

        PackageHelper::delete($request->all());
        
        return $this->respondWithOk();
    }

    /**
     * Fetches the package metadata.
     *
     * @param  \App\Http\Requests\EmployeeRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function fetchPackageMetadata(EmployeeRequest $request)
    {
        $this->validateRequest($request, [
            'file'  => 'max:25000|mimes:zip',
            'src'   => 'nullable',
        ]);

        if ($request->hasFile('file')) {
            $metadata = PackageHelper::fetchMetadataFromUploadedFile($request->file('file'));
        } else {
            $metadata = PackageHelper::fetchMetadata($request->src);
        }

        return $this->respondWithJson($metadata);
    }

    /**
     * Creates a new DNS zone.
     *
     * @param  \App\Http\Requests\EmployeeRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function createDnsZone(EmployeeRequest $request)
    {
        $this->validateRequest($request, [
            'name' => 'required|string'
        ]);

        if (! PermissionHelper::canUserCreateDnsZone($request->user)) {
            return $this->respondWithUnauthorized();
        };

        $dnsZone = DnsZoneHelper::create($request->all());
        
        return $this->respondWithItem($dnsZone);
    }

    /**
     * Creates a new DNS zone.
     *
     * @param  \App\Http\Requests\EmployeeRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function deleteDnsZone(EmployeeRequest $request)
    {
        $this->validateRequest($request, [
            'dns_zone_slug' => 'required|exists:dns_zones,slug',
        ]);

        if (! PermissionHelper::canUserDeleteDnsZone($request->user, $request->dns_zone)) {
            return $this->respondWithUnauthorized();
        };

        DnsZoneHelper::delete($request->all());
        
        return $this->respondWithOk();
    }

    /**
     * Creates a new or update an existing DNS zone record.
     *
     * @param  \App\Http\Requests\EmployeeRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function createOrUpdateDnsZoneRecord(EmployeeRequest $request)
    {
        $this->validateRequest($request, [
            'dns_zone_slug' => 'required|exists:dns_zones,slug',
            'name'          => 'required|string',
            'type'          => 'required|string',
            'values'        => 'required|array',
            'ttl'           => 'required|integer',
        ]);

        if (! PermissionHelper::canUserUpdateDnsZone($request->user, $request->dns_zone)) {
            return $this->respondWithUnauthorized();
        };

        $dnsZone = DnsZoneHelper::changeRecord($request->all());
        
        return $this->respondWithItem($dnsZone);
    }

    /**
     * Delets an existing DNS zone record.
     *
     * @param  \App\Http\Requests\EmployeeRequest  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function deleteDnsZoneRecord(EmployeeRequest $request)
    {
        $this->validateRequest($request, [
            'dns_zone_slug' => 'required|exists:dns_zones,slug',
            'name'          => 'required|string',
            'type'          => 'required|string',
            'values'        => 'required|array',
            'ttl'           => 'required|integer',
        ]);

        if (! PermissionHelper::canUserUpdateDnsZone($request->user, $request->dns_zone)) {
            return $this->respondWithUnauthorized();
        };

        DnsZoneHelper::deleteRecord($request->all());
        
        return $this->respondWithOk();
    }

    /**
     * Returns request parameters with partner.
     *
     * @param  \App\Http\Requests\EmployeeRequest  $request
     *
     * @return \Illuminate\Http\Request
     */
    private function requestAllWithPartner(EmployeeRequest $request)
    {
        $partner = $request->user->parent;
        return array_merge(
            $request->all(),
            [
                'partner' => $partner,
                'partner_slug' => $partner->slug
            ]
        );
    }
}
